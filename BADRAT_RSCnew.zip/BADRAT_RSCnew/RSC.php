<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<TITLE>RSC</TITLE>

<STYLE type="text/css">

H1 {
    color : #cc1808;
    text-align : center;
  }


H4 {
    left : 10pc;
    margin-left : -2.5pc;
  }


.B {
    text-align : center;
  }


a.perissotera:link {
    color : #000000;
  }


a.perissotera:visited {
    color : #000000;
  }


a.perissotera:hover {
    color : #cc1808;
  }


a.perissotera:active {
    color : #cc1808;
  }


div.header {
    border-bottom-color : #cc1808;
    border-bottom-style : solid;
    border-bottom-width : 3px;
    border-left-color : #cc1808;
    border-left-style : solid;
    border-left-width : 3px;
    border-right-color : #cc1808;
    border-right-style : solid;
    border-right-width : 3px;
    border-top-color : #cc1808;
    border-top-style : solid;
    border-top-width : 3px;
    width : 100%;
  }


div.body {
    width : 100%;
  }


div.left {
    border-left-color : #cc1808;
    border-left-style : solid;
    border-left-width : 1px;
    border-right-color : #cc1808;
    border-right-style : solid;
    border-right-width : 1px;
    float : left;
    height : 36.5pc;
    line-height : 18px;
    margin-bottom : 0px;
    text-align : left;
    width : 12%;
  }


table.maintable {
    border-bottom-color : #cc1808;
    border-bottom-style : ridge;
    border-bottom-width : 8px;
    border-left-color : #cc1808;
    border-left-style : ridge;
    border-left-width : 8px;
    border-right-color : #cc1808;
    border-right-style : ridge;
    border-right-width : 8px;
    border-top-color : #cc1808;
    border-top-style : ridge;
    border-top-width : 8px;
    height : 20pc;
    margin-left : 35.5%;
    padding-bottom : 2px;
    padding-left : 2px;
    padding-right : 2px;
    padding-top : 2px;
    table-layout : fixed;
    width : 30pc;
  }


b.sizemain {
    font-size : 20px;
  }


ul.li {
    line-height : 20px;
  }


div.lefttop {
    border-bottom-color : #cc1808;
    border-bottom-style : ridge;
    border-bottom-width : 1px;
    border-left-color : #cc1808;
    border-left-style : ridge;
    border-left-width : 1px;
    border-right-color : #cc1808;
    border-right-style : ridge;
    border-right-width : 1px;
    border-top-color : #cc1808;
    border-top-style : ridge;
    border-top-width : 1px;
    height : 13pc;
    margin-left : 12pc;
    margin-top : -20pc;
    padding-bottom : 1pc;
    padding-right : 1pc;
    padding-top : 1pc;
    text-align : justify;
    width : 20pc;
  }


img {
    float : right;
    height : 5pc;
    width : 5pc;
  }


div.leftbottom {
    border-bottom-color : #cc1808;
    border-bottom-style : ridge;
    border-bottom-width : 3px;
    border-left-color : #cc1808;
    border-left-style : ridge;
    border-left-width : 3px;
    border-right-color : #cc1808;
    border-right-style : ridge;
    border-right-width : 3px;
    border-top-color : #cc1808;
    border-top-style : ridge;
    border-top-width : 3px;
    height : 15.3pc;
    margin-left : 12pc;
    margin-top : 1pc;
    padding-bottom : 1pc;
    padding-right : 1pc;
    padding-top : 1pc;
    width : 20pc;
  }


div.centerbottom {
    border-bottom-color : #cc1808;
    border-bottom-style : double;
    border-bottom-width : 3px;
    border-left-color : #cc1808;
    border-left-style : double;
    border-left-width : 3px;
    border-right-color : #cc1808;
    border-right-style : double;
    border-right-width : 3px;
    border-top-color : #cc1808;
    border-top-style : double;
    border-top-width : 3px;
    height : 12.5pc;
    margin-left : 34.5pc;
    margin-top : -13pc;
    width : 30pc;
  }


div.righttop {
    border-bottom-color : #cc1808;
    border-bottom-style : outset;
    border-bottom-width : 3px;
    border-left-color : #cc1808;
    border-left-style : outset;
    border-left-width : 3px;
    border-right-color : #cc1808;
    border-right-style : outset;
    border-right-width : 3px;
    border-top-color : #cc1808;
    border-top-style : outset;
    border-top-width : 3px;
    height : 19.8pc;
    margin-left : 66pc;
    margin-top : -34.5pc;
    width : 20pc;
  }


div.rightbottom {
    border-bottom-color : #cc1808;
    border-bottom-style : outset;
    border-bottom-width : 3px;
    border-left-color : #cc1808;
    border-left-style : outset;
    border-left-width : 3px;
    border-right-color : #cc1808;
    border-right-style : outset;
    border-right-width : 3px;
    border-top-color : #cc1808;
    border-top-style : outset;
    border-top-width : 3px;
    height : 13.2pc;
    margin-left : 66pc;
    margin-top : 0.8pc;
    width : 20pc;
  }


marquee {
    background-color : #000000;
    border-bottom-color : #cc1808;
    border-bottom-style : solid;
    border-bottom-width : 1px;
    border-left-color : #cc1808;
    border-left-style : solid;
    border-top-color : #cc1808;
    border-top-style : solid;
    bottom : 100%;
    width : 100%;
  }


.marquee {
    color : #fbfbfb;
    font-weight : bold;
  }

</STYLE>


</head>

<BODY>
<div class="body">
<div class="header">
<H1>rAT sTATION cENTER (RSC)</H1>
</div>
<div class="left">
<A class="perissotera" href="RSC.php" target="_parent">Αρχική σελίδα</A>
<ul>
<h4><strong>ΣΤΑΘΜΟΣ</strong></h4>
<LI><A class="perissotera" href="kena.php" target="_parent">Κενά σε εκπομπές</A></LI>
<li><A class="perissotera" href="allages.php" target="_parent">Αλλαγές</A></li>
<li><A class="perissotera" href="nees_thesis.php" target="_parent">Νέες Θέσεις</A></li>
<LI><A class="perissotera" href="top_themata.php" target="_parent">Top θέματα</A></LI>
<h4><strong>ΟΜΑΔΑ</strong> bad-rat</h4>
<LI><A class="perissotera" href="protaseis_idees.php" target="_parent">Προτάσεις/<BR>Ιδέες</A></LI>
<LI><A class="perissotera" href="genikes_suzhthseis.php" target="_parent">Γενικές Συζητήσεις</A></LI>
<LI><A class="perissotera" href="erwtisis.php" target="_parent">Ερωτήσεις</A></LI>
<h4><STRONG>ΠΛΗΡΟΦΟΡΙΕΣ</STRONG></h4>
<LI><A class="perissotera" href="upeuthunoi.php" target="_parent">Υπεύθυνοι</A></LI>
<LI><A class="perissotera" href="leptomeries.php" target="_parent">Λεπτομέριες Εκπομπών</A></LI>
<LI><A class="perissotera" href="epishmo e-mail.php" target="_parent">Επίσημο e-mail</A></LI>
</ul>
</div>

<table class="maintable">
  <caption><b class="sizemain">ΑΝΑΚΟΙΝΩΣΕΙΣ</b></caption>
  <tbody>
    <tr>
      <td>
        <ul class="li">
        <img src="pictures/announcement1.gif" width="432" height="362">
        <LI>o giannhs edire to mpamph</LI>
        <LI>alla ges sto programma ekpompwn</LI>
        <LI>kapoia anakoinwsh k edw</LI> 
        <LI>kapoia anakoinwsh k edw</LI> 
        <LI>kapoia anakoinwsh k edw</LI>
        <LI>kapoia anakoinwsh k edw</LI>
        <LI>kapoia anakoinwsh k edw kapoia anakoinwsh k edwkapoia anakoinwsh k edwkapoia anakoinwsh k edw</LI></ul>
      </td>
    </tr>
  </tbody>
</table>

<div class="lefttop"><B class="B">ΚΕΝΑ ΣΕ ΕΚΠΟΜΠΕΣ</B>
<ul>
<img src="pictures/sad_desktop.jpg" width="300" height="249">
   <li> 20/12/09 20:00-22:00 ogen </li>
   <li> 23/12/09 18:00-20:00 xristos & mpamphs </li>
   <li> 30/12/09 12:00-16:00 nikolia ante geia </li>
   <LI> 25/02/09 45:00-47:00 blakas blakentios </LI>
</ul>
<A class="perissotera" href="kena.php" target="_parent"><b>+</b> Δείτε περισσότερα</A>
</div>

<div class="leftbottom"><b class="B">Top</b> Θέματα σταθμού <br>
<?php
$con =mysql_connect("localhost","root","mysqlubuntu8.04");
if (!$con)
	{
	die ('Δεν μπόρεσε να συνδεθεί: ' . mysql_error());
	}
mysql_select_db("bcastinfo", $con);
$result= mysql_query("SELECT * FROM top_themata ORDER BY top_themata.ID_top DESC ;");
$n=0;
WHILE(($row= mysql_fetch_array($result)) && $n<4)
	{
	$topthemata.= "".$row["title"]."&nbsp;&nbsp;".$row["date"]."<br><br>";
	$n++;
	}
echo $topthemata;
?>
</div>

<div class="centerbottom"><B class="B">Αλλαγές</B>
<?php
$con = mysql_connect("localhost","root","mysqlubuntu8.04");
	if (!$con)
		{
		die ('Δεν μπόρεσε να συνδεθεί: ' . mysql_error());
		}
mysql_select_db("bcastinfo", $con);
$result = mysql_query(" SELECT * FROM allages ORDER BY allages.tID DESC ;");
$n=0;
WHILE (($row=mysql_fetch_array($result)) && $n<4)
	{
	$allagestxt.= "<p>".$row["title"]."&nbsp;&nbsp;".$row["DATE"]."</p>";
	$n++;
	}
echo $allagestxt;
?>

<A class="perissotera" href="allages.php" name="anaprosarmoges" target="_blank"><b>+</b> Δείτε περισσότερα</A>
</DIV>

<DIV class="righttop"></DIV>

<DIV CLASS="rightbottom"></DIV>

</div>
<div><marquee class="marquee">mpla mplamplampla mplampla mplampla    mplampla mplamplamplampla.:;.:;"'?;?;?;!?;!?;!?;!?;!?;!?;</marquee></div>
</BODY>
<html>